export interface Gadget {
  id: number;
  name: string;
  brand: string;
  category: string;
  releaseDate: string;
  price: number;
  isAvailable: boolean;
}